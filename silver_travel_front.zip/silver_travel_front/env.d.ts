// src/env.d.ts
/// <reference types="vite/client" />
