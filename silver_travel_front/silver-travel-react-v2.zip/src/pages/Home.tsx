import React, { useState } from 'react'
import { Layout, Card } from 'antd'
import ChatInput from '../components/ChatInput'

const { Content } = Layout

const Home = () => {
  const [question, setQuestion] = useState('')
  const [answer, setAnswer] = useState('')

  const handleSubmit = () => {
    if (!question.trim()) return
    setAnswer(`🧠 AI 回复（模拟）：「${question}」的建议是：建议您选择慢节奏、低海拔、交通便利的行程路线。`)
    setQuestion('')
  }

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Content style={{ padding: '24px', maxWidth: '720px', margin: 'auto' }}>
        <Card title="银发旅游问答助手">
          <ChatInput value={question} onChange={setQuestion} onSubmit={handleSubmit} />
        </Card>

        {answer && (
          <Card title="AI 回复" style={{ marginTop: 24 }}>
            {answer}
          </Card>
        )}
      </Content>
    </Layout>
  )
}

export default Home
